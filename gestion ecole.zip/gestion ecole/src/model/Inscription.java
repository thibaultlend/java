/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author nmalk
 */
public class Inscription {
    //attribut
    private int id;
    private int Classe_id;
    private int Personne_id;
    
    //constructeur
    public Inscription()
    {
        id=0;
        Classe_id=0;
        Personne_id=0;
    }
    
    //constructeur surchargé
    public Inscription(int p_id, int pci, int ppi) {
        id = p_id;
        Classe_id = pci;
        Personne_id = ppi;
    }

    //getter et setter
    public int getId() {
        return id;
    }

    public int getPci() {
        return Classe_id;
    }

    public int getPpi() {
        return Personne_id;
    }

    public void setId(int p_id) {
        id = p_id;
    }

    public void setPci(int pci) {
        Classe_id = pci;
    }

    public void setPpi(int ppi) {
        Personne_id = ppi;
    }
}
