/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author nmalk
 */
public class Classe {
    //attribut
    private int id;
    private String nom;
    private int AnneeScolaire_id;
    private int Ecole_id;
    private int Niveau_id;
    
    
    //constructeur 
    public Classe(){
        id=0;
        nom=null;
        AnneeScolaire_id=0;
        Ecole_id=0;
        Niveau_id=0;
    }
    
    //constructeur surchargé
    public Classe(int p_id, String p_nom, int pasi, int pei, int pni){
        id=p_id;
        nom=p_nom;
        AnneeScolaire_id=pasi;
        Ecole_id=pei;
        Niveau_id=pni;
    }
    
    //getter et setter
    public int getId(){
        return id;
    }
    
     public String getNom(){
        return nom;
    }
     
     public int getPasi(){
        return AnneeScolaire_id;
    }
     
     public int getPei(){
        return Ecole_id;
    } 
    
     public int getPni(){
        return Niveau_id;
    }
     
     public void setId(int p_id){
         id=p_id;
     }
     
     public void setNom(String p_nom){
         nom=p_nom;
     }
     
     public void setPasi(int pasi){
         AnneeScolaire_id=pasi;
     }
     
     public void setPei(int pei){
         Ecole_id=pei;
     }
     
     public void setPni(int pni){
         Niveau_id=pni;
     }
     
}   
