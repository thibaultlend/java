/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author nmalk
 */
public class Bulletin {
    //attribut
    private int id;
    private String appreciation;
    private int trimestre_id;
    private int inscription_id;

    //constructeur
    public Bulletin(){
        id=0;
        appreciation=null;
        trimestre_id=0;
        inscription_id=0;
    }

    //constructeur surchargé
    public Bulletin (int p_id, String p_appreciation, int pti, int pii){
        id=p_id;
        appreciation=p_appreciation;
        trimestre_id=pti;
        inscription_id=pii;
    }
    
    //getter et setter
    public int getId(){
        return id;
    }
     
     public String getAppreciation(){
        return appreciation;
    }
     
    public int getTrimestre_id(){
        return trimestre_id;
    }
    
    public int getInscription_id(){
        return inscription_id;
    }
    
    public void setId(int p_id){
        id=p_id;
    }
    
    public void setAppreciation(String p_appreciation){
            appreciation=p_appreciation;
    }
    
     public void setTrimestre_id(int pti){
            trimestre_id=pti;
    }
     public void setInscription_id(int pii){
         inscription_id=pii;
     }
     
}
