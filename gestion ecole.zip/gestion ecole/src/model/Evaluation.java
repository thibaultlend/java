/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author nmalk
 */
public class Evaluation {
    //attribut
    private int id;
    private int note;
    private String appreciation;
    private int DetailBulletin_id;
    
    //constructeur
    public Evaluation(){
        id=0;
        note=0;
        appreciation=null;
        DetailBulletin_id=0;
    }

    //constructeur surchargée
    public Evaluation(int p_id, int p_note, String pa, int pdbi) {
        id = p_id;
        note = p_note;
        appreciation = pa;
        DetailBulletin_id = pdbi;
    }

    //getter et setter
    public int getId() {
        return id;
    }

    public int getNote() {
        return note;
    }

    public String getPa() {
        return appreciation;
    }

    public int getPdbi() {
        return DetailBulletin_id;
    }

    public void setId(int p_id) {
        id = p_id;
    }

    public void setNote(int p_note) {
        note = p_note;
    }

    public void setPa(String pa) {
        appreciation = pa;
    }

    public void setPdbi(int pdbi) {
        DetailBulletin_id = pdbi;
    }
}
